// Import the faker package
//const faker = require('faker');


const email = "gheoj;lmd";

console.log(email);