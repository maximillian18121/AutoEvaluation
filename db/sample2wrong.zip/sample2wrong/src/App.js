

function App() {
  return (
    <div className="App main-container">
     <h data-test="header-1">This is first test Case</h1>
     <h2 data-test="header-2">This is second test Case</h2>
     <h data-test="header-3">This is third test Case</h3>
    </div>
  );
}

export default App;
